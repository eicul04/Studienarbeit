@FormDefinition(identifier = PlpWrapper.EDIT_VIEW,  variant = FormGroupVariant.VARIANT_HIDE, groups = {
	@FormGroup(identifier = "budgetdaten", groupOpened = false,
		properties = {
			@FormProperty(name = "budgetdaten", emptyLabel = true, pojoAsFormField = true, fillLabelHorizontal = true, fillFieldHorizontal = true)
			}, layout = @GridLayout(columns = 1, rows = 1, columnDefinitions = {
				@GridLayoutColumnDefinition(column = 0, ratio = 1)
			})
	),
})

@ActionDefinition(identifier = "PlpActionsEdit", actions = {
	@ActionMethod(name = "save",  		scope = ActionScope.FORM_TOOLBAR, iconName = IconConstants.ICON_FLOPPY_DISK, styleName=ValoTheme.BUTTON_BORDERLESS)
})

@HeaderDefinition(identifier = "PlpHeaderEdit", properties = {
	@HeaderProperty(name = "kostenstelle", labelRow1 = 0, labelColumn1 = 0, fieldRow1 = 0, fieldColumn1 = 1),
	@HeaderProperty(name = "jahr", formatPattern = "0000", labelRow1 = 0, labelColumn1 = 3, fieldRow1 = 0, fieldColumn1 = 4)
}, layout = @GridLayout(columns = 6, rows = 1,columnDefinitions = {
    @GridLayoutColumnDefinition(column = 0, ratio = 1),
    @GridLayoutColumnDefinition(column = 1, ratio = 1),
    @GridLayoutColumnDefinition(column = 2, ratio = 2),
    @GridLayoutColumnDefinition(column = 3, ratio = 1),
    @GridLayoutColumnDefinition(column = 4, ratio = 1),
    @GridLayoutColumnDefinition(column = 5, ratio = 20)
}))

@ViewDefinition(identifier = PlpWrapper.EDIT_VIEW, formDefinition = PlpWrapper.EDIT_VIEW, headerDefinition = "PlpHeaderEdit", actionDefinition = "PlpActionsEdit")
