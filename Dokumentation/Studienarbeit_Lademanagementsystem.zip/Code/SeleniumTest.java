class PlpNewTest extends AbstractPlpSeleniumTest {

	private NewPlpPage newPlpPage;

	private static final Integer YEAR_DEFAULT_VALUE = Calendar.getInstance().get(Calendar.YEAR) + 1;
	private static final String TATORT_KOSTENSTELLE = "525313 Tatort Baden-Württemberg";
	public static final String KOSTENSTELLE_COMBOBOX_ID_EDIT = "field.newbudgetsatzdialogwrapper.kostenstelle.fd_new.fg1";

	@BeforeEach
	public void setup() {
		navigateTo(this.testProperties.getPlpUrl());
		loginWithDefaultCredentials();
		this.newPlpPage = new NewPlpPage(webDriver());
	}

	@Test
	void testCreateNewPlpAndAssertThatCorrectDataIsLoadedOnStartup() {
		newPlpPage.clickCreateBudgetsatzButton();
		newPlpPage.selectComboboxItemByText(KOSTENSTELLE_COMBOBOX_ID_EDIT, TATORT_KOSTENSTELLE);
		PlpPage plpSwrPage = newPlpPage.saveNewBudgetsatz();
		plpSwrPage.waitUntilHeaderContainsText("525313");
		plpSwrPage.waitUntilHeaderContainsText("Tatort Baden-Wuerttemberg");
		plpSwrPage.waitUntilHeaderContainsText(YEAR_DEFAULT_VALUE.toString());
	}
}