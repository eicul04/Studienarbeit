@Import(ConnectClientTestConfiguration.class)
@RestClientTest(ConnectClient.class)
@TestPropertySource("classpath:application-it.properties")
class ConnectClientIT {
	@Autowired
	@Qualifier("oauth2RestTemplate")
	private RestTemplate restTemplateMock;

	@Autowired
	private ConnectClient underTest;

	@MockBean
	private ConnectClientProperties mockConnectClientProperties;

	@Autowired
	private MockRestServiceServer mockRestServiceServer;

	@MockBean
	private PlpNotification plpNotificationMock;

	@MockBean
	private EncodingUtils encodingUtilsMock;

	private Resource kostenstelleResource = new ClassPathResource("kostenstelle.json", this.getClass());

	@BeforeEach
	void setUp() {
		mockRestServiceServer = MockRestServiceServer.bindTo(this.restTemplateMock).build();
	}

	@Test
	void testFindKostenstelleByNumberAndDate() throws JsonProcessingException {
		String url = StringUtils.join("http://localhost/kostenstellen/", KOSTENSTELLE_VALID, "/", CURRENT_DATE);
		mockRestServiceServer.expect(MockRestRequestMatchers.method(HttpMethod.GET)).andExpect(MockRestRequestMatchers.requestTo(url))
			.andRespond(MockRestResponseCreators.withSuccess(kostenstelleResource, MediaType.APPLICATION_JSON));
        ...
	}
}