/* create Budgetdata Table */
CREATE SEQUENCE plp_budgetdaten_id_seq  START WITH 1 INCREMENT BY 1;
CREATE TABLE plp_budgetdaten (
	id                         number(19,0)             default plp_budgetdaten_id_seq.nextval         not null,
	termin_anzahl             number(19,0),
	erstsendungen             number(19,0),
	sendedauer             number(19,0),
	programm_mittel             number(19,0),
	betriebskosten             number(19,0),
    PRIMARY KEY (id)
);
GRANT SELECT ON plp_budgetdaten_id_seq TO miss_plp_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON plp_budgetdaten TO miss_plp_app;