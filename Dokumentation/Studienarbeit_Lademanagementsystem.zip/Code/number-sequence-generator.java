@Entity
@Table(name = "PLP_NUMMER_SEQUENCE")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PlpNummerSequence {

	@Getter
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "plp_nummer_seq_generator")
	@SequenceGenerator(sequenceName = "plp_nummer_seq", allocationSize = 1, name = "plp_nummer_seq_generator")
	@Column(name = "PLP_NUMMER", nullable = false, precision = 22, scale = 0)
	private Long plpNummer;
}
