@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "PLP_BUDGETDATEN")
public class PlpBudgetdatenEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "plp_budgetdaten_id_seq_generator")
	@SequenceGenerator(sequenceName = "plp_budgetdaten_id_seq", allocationSize = 1, name = "plp_budgetdaten_id_seq_generator")
	@Column(name = "ID", nullable = false, precision = 22, scale = 0)
	private Long id;

	@OneToOne(mappedBy = "budgetdatenEntity")
	private PlpDataEntity plpdata;

	@Column(name = "TERMIN_ANZAHL")
	private Long terminAnzahl;

	@Column(name = "ERSTSENDUNGEN")
	private Long erstsendungen;

	@Column(name = "SENDEDAUER")
	private Long sendedauer;

	@Column(name = "PROGRAMM_MITTEL")
	private Long programmMittel;

	@Column(name = "BETRIEBSKOSTEN")
	private Long betriebskosten;
}