@ExtendWith(MockitoExtension.class)
class PlpValidationServiceTest {
	private static final Integer VALID_JAHR = 2000;
	private static final Integer INVALID_JAHR = 1969;
	private static final String ERROR_MESSAGE = "Error Message";

	@InjectMocks
	private PlpValidationService underTest;

	@Mock
	private MessagesUtil messagesUtilMock;

	@Test
	void testJahrReturnsNullIfCorrectInput() {
		assertThat(underTest.validateJahr(VALID_JAHR)).isNull();
	}
	
	@Test
	void testJahrReturnsErrorMessageIfYearIsBefore1970() {
		when(messagesUtilMock.getI18nString(Mockito.anyString())).thenReturn(ERROR_MESSAGE);
		assertThat(underTest.validateJahr(INVALID_JAHR)).isEqualTo(ERROR_MESSAGE);
	}
}