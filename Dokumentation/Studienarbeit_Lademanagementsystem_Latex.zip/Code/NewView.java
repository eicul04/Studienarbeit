@SpringView(name = "new")
public class PlpNewView extends VerticalLayout implements View {

	@Autowired
	private transient PlpViewFormBuilder plpViewFormBuilder;
	
	@Autowired
	private transient BeanProvider beanProvider;

	@Override
	public void enter(ViewChangeEvent event) {
		PlpWrapper model = new PlpWrapper(beanProvider);
		buildUserInterface(model);
	}

	private void buildUserInterface(PlpWrapper model) {
		FormImpl form = plpViewFormBuilder.buildForm(model, PlpWrapper.NEW_VIEW);
		Component formContent = form.getContent();
		formContent.addStyleName(MissTheme.FIXED_SPLITPANEL_LAYOUT);
		addComponentsAndExpand(formContent);
		setMargin(false);
	}

}